console.log("Edgar");
console.log("Ingenieria en Computacion");
console.log("Ceti Colomos");
console.log("Me apasiona la computacion");
console.log("C, C++, Java, Javascript, Python, Rust");

