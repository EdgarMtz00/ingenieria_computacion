fn main() {
    println!("Edgar");
    println!("Ingenieria en Computacion");
    println!("Ceti Colomos");
    println!("Me apasiona la computacion");
    println!("C, C++, Java, Javascript, Python, Rust");
}
