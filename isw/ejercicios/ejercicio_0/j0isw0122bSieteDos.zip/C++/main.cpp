#include <iostream>
using namespace std;

int main (int argc, char *argv[])
{
  cout << "Edgar\n";
  cout << "Ingenieria en Computacion\n";
  cout << "Ceti Colomos\n";
  cout << "Me apasiona la computacion\n";
  cout << "C, C++, Java, Javascript, Python, Rust\n";
  return 0;
}
