#include <stdlib.h>
#include <stdio.h>

int main (int argc, char *argv[])
{
  printf("Edgar\n");
  printf("Ingenieria en Computacion\n");
  printf("Ceti Colomos\n");
  printf("Me apasiona la computacion\n");
  printf("C, C++, Java, Javascript, Python, Rust\n");
  return 0;
}
