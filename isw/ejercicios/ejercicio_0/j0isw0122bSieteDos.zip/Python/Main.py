if __name__ == "__main__":
    print("Edgar")
    print("Ingenieria en Computacion")
    print("Ceti Colomos")
    print("Me apasiona la computacion")
    print("C, C++, Java, Javascript, Python, Rust")
